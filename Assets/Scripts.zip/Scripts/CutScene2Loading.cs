﻿using UnityEngine;
using UnityEngine.SceneManagement;

public class CutScene2Loading : MonoBehaviour
{
    public void LoadNextScene()
    {
        SceneManager.LoadScene("Cutscene2");
    }

    public void NoUnlock()
    {
        CutSceneFlags.noClicked = true;  // tell system No was clicked
        SceneManager.LoadScene("DemoTesting2");
    }
}
