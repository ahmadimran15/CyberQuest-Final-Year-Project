using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class CutScene1topanel : MonoBehaviour
{
    private Collider doorCollider; // Reference to the door collider

    void Start()
    {
        // Find "Door 3" GameObject in the scene
        GameObject door = GameObject.Find("Door 3");

        if (door != null)
        {
            doorCollider = door.GetComponent<Collider>();
            if (doorCollider != null)
            {
                doorCollider.enabled = false; // Disable door collider initially
            }
        }
        else
        {
            Debug.LogError("Door 3 not found! Check the name in Hierarchy.");
        }

        StartCoroutine(SwitchSceneAfterDelay());
    }

    IEnumerator SwitchSceneAfterDelay()
    {
        // Wait for 14 seconds (cutscene duration)
        yield return new WaitForSecondsRealtime(4f);

        // Enable door collider before switching scene
        if (doorCollider != null)
        {
            doorCollider.enabled = true;
        }

        // Load the next scene
        SceneManager.LoadScene("Panel_to_cutscene2");
    }
}
