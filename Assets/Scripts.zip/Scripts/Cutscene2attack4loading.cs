using UnityEngine;
using UnityEngine.SceneManagement;

public class Cutscene2attack4loading : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "Main Camera") // Detect Main Camera entering
        {
            SceneManager.LoadScene("Cutscene2attack4"); // Load the cutscene
        }
    }

}
