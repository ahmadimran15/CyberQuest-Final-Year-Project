using UnityEngine;
using UnityEngine.SceneManagement;


public class CutScene3Loading: MonoBehaviour
{
    
    public void LoadNextScene2()
    {
        // This will load the scene with the specified name or build index
        SceneManager.LoadScene("Cutscene2");  // Use scene name
                                 
    }


}
