using UnityEngine;
using UnityEngine.SceneManagement;

public class BookshelfTrigger : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "Main Camera") // Detect Main Camera entering
        {
            SceneManager.LoadScene("Cutscene1"); // Load the cutscene
        }
    }
}
