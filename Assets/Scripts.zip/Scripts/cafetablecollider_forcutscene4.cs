using UnityEngine;
using UnityEngine.SceneManagement;


public class cafetablecollider_forcutscene4 : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "Main Camera") // Detect Main Camera entering
        {
            SceneManager.LoadScene("Cutscene4"); // Load the cutscene
        }
    }
}
