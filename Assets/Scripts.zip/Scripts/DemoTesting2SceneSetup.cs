﻿using UnityEngine;
using TMPro;

public class DemoTesting2SceneSetup : MonoBehaviour
{
    void Start()
    {
        // ✅ Only if No was clicked
        if (CutSceneFlags.noClicked)
        {
            // Enable nocutscene script
            GameObject nocutsceneObj = GameObject.Find("nocutscene");
            if (nocutsceneObj != null)
            {
                nocutsceneObj.GetComponent<NOCutsceneLoading>().enabled = true;
                Debug.Log("NOCutsceneLoading script enabled.");
            }

            // Update Task Text
            GameObject taskObject = GameObject.Find("TaskText");
            if (taskObject != null)
            {
                var taskText = taskObject.GetComponent<TextMeshProUGUI>();
                taskText.text = "Explore the Library";
            }

            // Optional: Disable LibraryManager
            GameObject libraryManager = GameObject.Find("LibraryManager");
            if (libraryManager != null)
            {
                libraryManager.SetActive(false);
                Debug.Log("LibraryManager Disabled.");
            }

            // Reset flag if you want it to only trigger once
            // CutSceneFlags.noClicked = false;   // Optional
        }
    }
}
