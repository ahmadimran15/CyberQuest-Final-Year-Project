using UnityEngine;
using UnityEngine.SceneManagement;

public class tablecollider_forcutscene3 : MonoBehaviour
{
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.name == "Main Camera") // Detect Main Camera entering
        {
            SceneManager.LoadScene("Cutscene3"); // Load the cutscene
        }
    }
}
