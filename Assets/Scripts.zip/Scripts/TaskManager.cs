using UnityEngine;
using TMPro;

public class TaskManager : MonoBehaviour
{
    public static TaskManager Instance; // Singleton for global access
    public TextMeshProUGUI taskText;

    void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // Keep task text across scenes
        }
        else
        {
            Destroy(gameObject); // Prevent duplicates
        }
    }

    public void UpdateTask(string newTask)
    {
        if (taskText != null)
        {
            taskText.text = newTask;
        }
        else
        {
            Debug.LogError("Task Text not assigned in TaskManager!");
        }
    }
}
