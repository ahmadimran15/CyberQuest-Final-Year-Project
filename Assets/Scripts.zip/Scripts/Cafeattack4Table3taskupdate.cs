﻿using UnityEngine;
using TMPro;

public class Cafeattack4Table3taskupdate : MonoBehaviour
{
    void Start()
    {
        //Only if No was clicked
        if (CutSceneFlags.FreeWifiClicked)
        {
            /*// Enable nocutscene script
            GameObject nocutsceneObj = GameObject.Find("nocutscene");
            if (nocutsceneObj != null)
            {
                nocutsceneObj.GetComponent<NOCutsceneLoading>().enabled = true;
                Debug.Log("NOCutsceneLoading script enabled.");
            }*/

            // Update Task Text
            GameObject taskObject = GameObject.Find("TaskText");
            if (taskObject != null)
            {
                var taskText = taskObject.GetComponent<TextMeshProUGUI>();
                taskText.text = "Go to Table 3 and sit";
            }

          /*  // Optional: Disable LibraryManager
            GameObject libraryManager = GameObject.Find("LibraryManager");
            if (libraryManager != null)
            {
                libraryManager.SetActive(false);
                Debug.Log("LibraryManager Disabled.");
            }*/

            // Reset flag if you want it to only trigger once
            // CutSceneFlags.noClicked = false;   // Optional
        }

        if (CutSceneFlags.ExitCafeClicked)
        {
            // Update Task Text
            GameObject taskObject = GameObject.Find("TaskText");
            if (taskObject != null)
            {
                var taskText = taskObject.GetComponent<TextMeshProUGUI>();
                taskText.text = "Exit the Cafe";
            }  
        }
    }
}
