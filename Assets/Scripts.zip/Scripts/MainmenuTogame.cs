using UnityEngine;
using UnityEngine.SceneManagement;

public class MainmenuTogame : MonoBehaviour
{
    public void LoadGamesceneAttack2and3()
    {
        SceneManager.LoadScene("DemoTesting2"); // Ensure "Cutscene1" matches the exact scene name in Build Settings
    }

    public void LoadGamesceneAttack4()
    {
        SceneManager.LoadScene("CafeSceneAttack4"); // Ensure "Cutscene1" matches the exact scene name in Build Settings
    }

    public void LoadGamesceneAttack3()
    {
        SceneManager.LoadScene("CafeSceneAttack2and3"); // Ensure "Cutscene1" matches the exact scene name in Build Settings
    }
}
