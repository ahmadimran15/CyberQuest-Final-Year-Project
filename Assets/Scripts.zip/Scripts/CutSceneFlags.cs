using UnityEngine;

public static class CutSceneFlags
{
    public static bool noClicked = false;
    public static bool FreeWifiClicked = false;
    public static bool ExitCafeClicked = false;
}
