using UnityEngine;
using UnityEngine.SceneManagement;

public class Cutscene4attack4loading : MonoBehaviour
{
    public void LoadNextScene()
    {
        // This will load the scene with the specified name or build index
        SceneManager.LoadScene("Cutscene4attack4");  // Use scene name

    }

}
