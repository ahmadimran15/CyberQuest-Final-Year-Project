using UnityEngine;

// PuzzleState.cs
public static class PuzzleState
{
    public static bool puzzleSolved = false;
}
